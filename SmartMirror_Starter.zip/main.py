from ui.display import start_display

if __name__ == "__main__":
    start_display()